declare module '@env' {
  export const ENV_PROJECT_ID: string;
}
